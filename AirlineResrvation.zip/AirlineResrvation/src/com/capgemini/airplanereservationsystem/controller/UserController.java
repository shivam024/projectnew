package com.capgemini.airplanereservationsystem.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.airplanereservationsystem.bean.Users;
import com.capgemini.airplanereservationsystem.exception.UserException;
import com.capgemini.airplanereservationsystem.service.IUserService;


@RestController
public class UserController {
	
	@Autowired
	private IUserService userservice;
	
	@RequestMapping(value ="/checkLogin",consumes = MediaType.APPLICATION_JSON_VALUE,headers="Accept=application/json",method = RequestMethod.POST)  
    public Users checkLogin(@RequestBody Users users) {
		try {
			Users usr= userservice.loginUser(users);
		} catch (UserException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return users;   
	
	}

	@RequestMapping(value ="/user/create",consumes = MediaType.APPLICATION_JSON_VALUE,headers="Accept=application/json",method = RequestMethod.POST)
    public void registrationDetails(@RequestBody Users users) {
		userservice.registerUser(users);
	}
}
