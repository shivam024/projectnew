package com.capgemini.airplanereservationsystem.bean;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "Booking")
public class Booking implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="seq")
	@SequenceGenerator(name="seq",sequenceName="seq_booking_no",
				allocationSize=1)
	@Column(name="Booking_Id")
	private int bookingId;
	
	@Column(name="cust_email")
	private String email;
	
	@Column(name="no_of_passenger")
	private int noOfPassenger;
	
	@Column(name="class_type")
	private String classType;
	
	@Column(name="total_fare")
	private int totalFare;
	
	@Column(name="seat_number")
	private int seatNo;
	
	@Column(name="CreditCard_info")
	private String creditCard;
	
	@Column(name="src_city")
	private String SourceCity;
	
	@Column(name="dest_city")
	private String Destiny;

	public Booking(int bookingId, String email, int noOfPassenger,
			String classType, int totalFare, int seatNo, String creditCard,
			String sourceCity, String destiny) {
		super();
		this.bookingId = bookingId;
		this.email = email;
		this.noOfPassenger = noOfPassenger;
		this.classType = classType;
		this.totalFare = totalFare;
		this.seatNo = seatNo;
		this.creditCard = creditCard;
		SourceCity = sourceCity;
		Destiny = destiny;
	}

	public Booking() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getBookingId() {
		return bookingId;
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getNoOfPassenger() {
		return noOfPassenger;
	}

	public void setNoOfPassenger(int noOfPassenger) {
		this.noOfPassenger = noOfPassenger;
	}

	public String getClassType() {
		return classType;
	}

	public void setClassType(String classType) {
		this.classType = classType;
	}

	public int getTotalFare() {
		return totalFare;
	}

	public void setTotalFare(int totalFare) {
		this.totalFare = totalFare;
	}

	public int getSeatNo() {
		return seatNo;
	}

	public void setSeatNo(int seatNo) {
		this.seatNo = seatNo;
	}

	public String getCreditCard() {
		return creditCard;
	}

	public void setCreditCard(String creditCard) {
		this.creditCard = creditCard;
	}

	public String getSourceCity() {
		return SourceCity;
	}

	public void setSourceCity(String sourceCity) {
		SourceCity = sourceCity;
	}

	public String getDestiny() {
		return Destiny;
	}

	public void setDestiny(String destiny) {
		Destiny = destiny;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "BookingInformation [bookingId=" + bookingId + ", email="
				+ email + ", noOfPassenger=" + noOfPassenger + ", classType="
				+ classType + ", totalFare=" + totalFare + ", seatNo=" + seatNo
				+ ", creditCard=" + creditCard + ", SourceCity=" + SourceCity
				+ ", Destiny=" + Destiny + "]";
	}


	

}
