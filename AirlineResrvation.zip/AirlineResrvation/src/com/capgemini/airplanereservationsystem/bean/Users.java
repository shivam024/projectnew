package com.capgemini.airplanereservationsystem.bean;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;

@Entity
public class Users {
	@Id
	@Column(name = "USER_ID")
	private String userId;

	@Column(name = "PASSWORD_")
	private String password;

	@Column(name = "FIRST_NAME")
	private String name;

	@Column(name = "EMAIL_ADDRESS")
	private String eMail;

	@Column(name = "MOBILE_NUMBER")
	private String mobileNo;

	@OneToMany()
	private List<Booking> bookings;

	public String getUserName() {
		return userId;
	}

	public void setUserName(String userName) {
		this.userId = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String geteMail() {
		return eMail;
	}

	public void seteMail(String eMail) {
		this.eMail = eMail;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public List<Booking> getBookings() {
		return bookings;
	}

	public void setBookings(List<Booking> bookings) {
		this.bookings = bookings;
	}

	public Users() {

	}

	public Users(String userName, String password2) {
		
	}

}