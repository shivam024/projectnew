package com.capgemini.airplanereservationsystem.service;

import java.util.List;

import com.capgemini.airplanereservationsystem.bean.Booking;

public interface IBookingService {
	
	public void addBooking(Booking book);
	
	public List<Booking> viewAllBookings();
	
	public void deleteBooking(int id);

}
