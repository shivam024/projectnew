package com.capgemini.airplanereservationsystem.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.airplanereservationsystem.bean.Booking;
import com.capgemini.airplanereservationsystem.dao.BookDAOImpl;
import com.capgemini.airplanereservationsystem.dao.IBookDAO;

@Service
@Transactional
public class BookingServiceImpl implements IBookingService{
	
	@Autowired
	private IBookDAO dao;
	
	public BookingServiceImpl() {
		dao = new BookDAOImpl(); 
	}

	@Override
	public void addBooking(Booking book) {
		// TODO Auto-generated method stub
		dao.addBooking(book);
		
	}

	@Override
	public List<Booking> viewAllBookings() {
		// TODO Auto-generated method stub
		return dao.viewAllBookings();
	}

	@Override
	public void deleteBooking(int id) {
		// TODO Auto-generated method stub
		dao.deleteBooking(id);
		
	}

}
