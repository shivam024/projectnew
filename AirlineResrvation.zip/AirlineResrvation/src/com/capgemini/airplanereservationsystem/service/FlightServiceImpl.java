package com.capgemini.airplanereservationsystem.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.airplanereservationsystem.bean.FlightInformation;
import com.capgemini.airplanereservationsystem.dao.FlightDAOImpl;
import com.capgemini.airplanereservationsystem.dao.IFlightDAO;


@Service
@Transactional
public class FlightServiceImpl implements IFlightService{
	
	@Autowired
	private IFlightDAO dao;
	
	public FlightServiceImpl() {
		dao = new FlightDAOImpl(); 
	}

	@Override
	public List<FlightInformation> viewAllFlights() {
		// TODO Auto-generated method stub
		return dao.viewAllFlights();
	}

}
