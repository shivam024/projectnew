package com.capgemini.airplanereservationsystem.service;

import com.capgemini.airplanereservationsystem.bean.Users;
import com.capgemini.airplanereservationsystem.exception.UserException;

public interface IUserService {
	Users registerUser(Users user); 
	Users loginUser(Users user)throws UserException;
	boolean findUserByEmail(String email, String phone, String username)
			throws UserException;


}
