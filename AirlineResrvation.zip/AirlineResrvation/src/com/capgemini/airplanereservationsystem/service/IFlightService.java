package com.capgemini.airplanereservationsystem.service;

import java.util.List;

import com.capgemini.airplanereservationsystem.bean.FlightInformation;

public interface IFlightService {
	
	public List<FlightInformation> viewAllFlights();

}
