package com.capgemini.airplanereservationsystem.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.airplanereservationsystem.bean.Users;
import com.capgemini.airplanereservationsystem.dao.IUserDAO;
import com.capgemini.airplanereservationsystem.exception.UserException;

@Service
@Transactional
public class UserServiceImpl implements IUserService{
	
	@Autowired
	private IUserDAO dao;

	@Override
	public Users registerUser(Users user){
		return dao.registerUser(user);
	}

	@Override
	public Users loginUser(Users user)
			throws UserException {
		return dao.loginUser(user);
	}

	@Override
	public boolean findUserByEmail(String email, String phone, String username)
			throws UserException {
		return dao.findUserByEmail(email, phone, username);
	}

}
