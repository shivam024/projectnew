package com.capgemini.airplanereservationsystem.dao;

import java.util.List;

import com.capgemini.airplanereservationsystem.bean.FlightInformation;

public interface IFlightDAO {
	
	public List<FlightInformation> viewAllFlights();

}
