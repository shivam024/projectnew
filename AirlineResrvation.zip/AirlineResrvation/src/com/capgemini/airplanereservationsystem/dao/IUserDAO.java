package com.capgemini.airplanereservationsystem.dao;

import com.capgemini.airplanereservationsystem.bean.Users;
import com.capgemini.airplanereservationsystem.exception.UserException;

public interface IUserDAO {
	
	Users registerUser(Users user); 
	Users loginUser(Users usr)throws UserException;
	boolean findUserByEmail(String email, String phone, String username)
			throws UserException;

}
