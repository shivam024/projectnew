package com.capgemini.airplanereservationsystem.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.airplanereservationsystem.bean.Booking;
import com.capgemini.airplanereservationsystem.bean.Booking;
import com.capgemini.airplanereservationsystem.bean.FlightInformation;

@Repository
public class BookDAOImpl implements IBookDAO{
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public void addBooking(Booking book) {
		// TODO Auto-generated method stub
		entityManager.persist(book);
		entityManager.flush();
		
	}

	@Override
	public List<Booking> viewAllBookings() {
		// TODO Auto-generated method stub
		String qry = "SELECT b FROM BookingInformation b";
		TypedQuery<Booking> query = entityManager.createQuery(qry,
				Booking.class);
		return query.getResultList();
	}

	@Override
	public void deleteBooking(int id) {
		// TODO Auto-generated method stub
		Query queryTwo=entityManager.
				createQuery("DELETE FROM BookingInformation WHERE bookingId=:bookid");
		queryTwo.setParameter("bookid",id);
		queryTwo.executeUpdate();
	}

}
