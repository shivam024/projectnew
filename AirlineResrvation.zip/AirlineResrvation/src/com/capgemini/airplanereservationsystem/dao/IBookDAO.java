package com.capgemini.airplanereservationsystem.dao;

import java.util.List;

import com.capgemini.airplanereservationsystem.bean.Booking;


public interface IBookDAO {
	
	public List<Booking> viewAllBookings();
	
	public void addBooking(Booking book);
	
	public void deleteBooking(int id);
	

}
