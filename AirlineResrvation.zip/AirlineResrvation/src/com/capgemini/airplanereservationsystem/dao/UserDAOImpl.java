package com.capgemini.airplanereservationsystem.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.capgemini.airplanereservationsystem.bean.Users;
import com.capgemini.airplanereservationsystem.exception.UserException;


@Repository
public class UserDAOImpl implements IUserDAO {
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public Users registerUser(Users Users)  {
		entityManager.persist(Users);
		entityManager.flush();
		return Users;
		
	}

	@Override
	public Users loginUser(Users usr) {
		Query query = entityManager.createQuery("from Users where UsersId = :Usersname");
		query.setParameter("Usersname",usr.getUserId() );
		Users user= (Users) query.getSingleResult();
		System.out.println(user.getName());
		if(user.getPassword().equals(usr.getPassword())) {
			 
			return usr;
		}
		else

		return null;
	}
	
	@Override
	public boolean findUserByEmail(String email,String phone,String Username) throws UserException {
		String hql = "from Users where EMAIL_ADDRESS= :email OR MOBILE_NUMBER= :phone OR Users_ID= Usersname:";
		Query query1 = entityManager.createQuery(hql);
		query1.setParameter("email", email);
		query1.setParameter("phone", phone);
		query1.setParameter("Usersname", Username);
		boolean f = query1.getSingleResult() != null;
				if(f){
					return true;
				}else
					return false;
	}



}
